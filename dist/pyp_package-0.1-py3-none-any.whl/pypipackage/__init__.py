from .main import hello

#controls what is available when the package is loaded